/**
 
 * Homework 1
 * Jim Mittler
 * 13 August 2025
 
 _Italic text_
 __Bold text__
 ~~Strikethrough text~~

 */

import Cocoa

var greeting = "Hello, from Jim Mittler"
print(greeting)
